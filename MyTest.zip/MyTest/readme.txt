--------------------------MyTest--------------------------
Autor: Arley Fellipe
Email: arley.fellipe@gmail.com
Descri��o: Sitema de login, casdastro e confirma��o por email, 
valida��o de email, valida��o de senhas, perfil, foto de perfil via
gravatar, sess�o de login e logout

Framework: Bootstrap
Banco de Dados: Mysql
Cliente: PHP

Para o MyTest funcionar perfeitamente crie um banco de dados os dados
abaixo:
 
banco de dados: admnetpl_bd_technological 
usu�rio: admnetpl_tech e senha
senha: mDfvq(5cLusoEA33B8

acesse o arquivo Class.systema.php e altere o email de acordo com
sua necessidade!